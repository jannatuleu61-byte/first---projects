<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Your custom CSS -->
    <link rel="stylesheet" href="../../css/style.css">
</head>
<body>

    <div class="dashboard d-flex">

        <!-- Sidebar  -->
        <aside class="dashboard-sidebar p-3">
            <h2 class="dashboard-heading">
                <a href="/" class="home-link" aria-label="Go to Home">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-house" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M8 3.293l6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6zm5 6.414V13.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V9.707l5-5 5 5z"/>
                    <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6 6a1 1 0 0 1-1.414 1.414L8 3.914 2.707 8.914A1 1 0 0 1 1.293 7.5l6-6z"/>
                </svg>
                </a>
                Dashboard Menu
            </h2>

            <ul class="list-unstyled">
                
                <li>
                    <span>Manage Books</span>
                    <ul class="list-unstyled pl-3">
                        <li class="active"><a href="create-book.html">Create Book</a></li>
                        <li><a href="view-books.html">View Books</a></li>
                    </ul>
                </li>
                <li>
                    <span>User Accounts</span>
                    <ul class="list-unstyled pl-3">
                        <li><a href="../users/create-user.html">Create User</a></li>
                        <li><a href="../users/view-users.html">View Users</a></li>
                    </ul>
                </li>
                <li>
                    <span>Student Accounts</span>
                    <ul class="list-unstyled pl-3">
                        <li><a href="../students/create-student.html">Create Student</a></li>
                        <li><a href="../students/view-students.html">View Students</a></li>
                    </ul>
                </li>
                
            </ul>
        </aside>
        <!-- Dashboard Main  -->
        <main class="dashboard-main flex-grow-1">
            <div class="dashboard-main-nav">
                <nav class="p-3">
                    <ul class="d-flex justify-content-between align-items-center list-unstyled">
                        <li>
                            <a href="#" class="hamburger" aria-label="Open menu">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                    <rect y="4" width="24" height="2" rx="1" fill="currentColor"/>
                                    <rect y="11" width="24" height="2" rx="1" fill="currentColor"/>
                                    <rect y="18" width="24" height="2" rx="1" fill="currentColor"/>
                                </svg>
                            </a>
                        </li>
                        
                        <li>
                            <span style="display: flex; align-items: center;">
                                <span style="margin-right: 10px; font-weight: 500;">John Doe</span>
                                <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Profile Picture" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">
                            </span>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="dashboard-container p-3">
                <h1>Edit Book</h1>
                

                <div class="row">
                    <div class="col-sm-12 col-md-8">

                        <form>
                            <div class="form-group">
                                <label for="bookTitle">Book Title</label>
                                <input type="text" class="form-control" id="bookTitle" placeholder="Enter book title">
                            </div>
                            <div class="form-group">
                                <label for="bookAuthor">Author</label>
                                <input type="text" class="form-control" id="bookAuthor" placeholder="Enter author name">
                            </div>
                            <div class="form-group">
                                <label for="bookGenre">Genre</label>
                                <input type="text" class="form-control" id="bookGenre" placeholder="Enter book genre">
                            </div>
                            <div class="form-group">
                                <label for="bookDescription">Description</label>
                                <textarea class="form-control" id="bookDescription" rows="3" placeholder="Enter book description"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </form>

                    </div>

                    <div class="col-sm-12 col-md-4"></div>
                </div>


            </div>
        </main>

    </div>

    <script src="./js/main.js"></script>

</body>
</html>